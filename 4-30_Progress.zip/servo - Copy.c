/*
 * servo.c
 *
 *  Created on: Apr 9, 2025
 *      Author: Paige Geiken and Aubrey Levenhagen
 */

//#include "ping.h"
#include "Timer.h"
#include "lcd.h"
#include <inc/tm4c123gh6pm.h>
#include <stdint.h>
#include <stdbool.h>

/**
 * Initializes Timer 1B and PB5 to generate a PWM signal for the servo motor.
 */
void servo_init(void) {
       SYSCTL_RCGCGPIO_R |= 0x02;                   // Enable clock on port B
       SYSCTL_RCGCTIMER_R |= 0x02;                  // Enable clock on timer 1

       while((SYSCTL_PRGPIO_R & 0x02) == 0);        // Wait for clock on port B
       while((SYSCTL_PRTIMER_R & 0x02) == 0);       // Wait for clock on timer 1

       // Configure PB5 as PWM output
       GPIO_PORTB_DIR_R |= 0x20;                    // Set PB5 as output
       GPIO_PORTB_DEN_R |= 0x20;                    // Enable digital function on PB5
       GPIO_PORTB_AFSEL_R |= 0x20;                  // Enable alternate function
       GPIO_PORTB_PCTL_R |= 0x00700000;             // Set PB5 to Timer1 1B CCP (PWM output)

       TIMER1_CTL_R &= 0xFEFF;                      // Disable Timer 1B during setup (clear bit 8)
       TIMER1_CFG_R |= 0x4;                         // Configure for 16-bit timer mode
       TIMER1_TBMR_R |= 0xA;                        // TimerB: PWM mode + periodic mode

       int pulse_period = 320000;                   // Full PWM period = 20 ms at 16 MHz

       TIMER1_TBILR_R = pulse_period & 0xFFFF;      // Set lower 16 bits of interval load
       TIMER1_TBPR_R = pulse_period >> 16;          // Set upper bits of interval load
       TIMER1_CTL_R |= 0x0100;                      // Enable Timer 1B
}

void servo_move(int degrees) {
    unsigned int turn = degrees * (133) + 10000;    // Convert degrees to PWM pulse width in clock ticks

    TIMER1_TBMATCHR_R = (320000 - turn) & 0xFFFF;   // Set lower 16 bits f match value
    TIMER1_TBPMR_R = (320000 - turn) >> 16;         // Set upper 8 bits of match value


/*
 * Original servo_move draft (not working)
 */
//    if (degrees > 180) {
//        degrees = 180;
//    }
//
//    uint32_t pulse_width = (uint32_t)((28992.0 * degrees / 180.0) + 874.0);
//    uint32_t match = 320000 - pulse_width;
//    TIMER1_TBMATCHR_R = match & 0xFFFF;
//    TIMER1_TBPMR_R = (match >> 16) & 0xFF;
//
//    timer_waitMillis(300);
}

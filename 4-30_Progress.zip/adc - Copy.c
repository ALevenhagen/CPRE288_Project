/*
 * acd.c
 *
 *  Created on: Apr 4, 2025
 *      Author: pgeiken
 */

#include "adc.h"
#include "uart-interrupt.h"
#include <stdint.h>
#include <math.h>

void adc_init() {
    SYSCTL_RCGCGPIO_R |= 0x02;
    SYSCTL_RCGCADC_R |= 0x01;
    GPIO_PORTB_AFSEL_R |= 0x10;
    GPIO_PORTB_DEN_R &= 0xEF;
    GPIO_PORTB_DIR_R &= 0xEF;
    GPIO_PORTB_AMSEL_R |= 0x10;
    GPIO_PORTB_ADCCTL_R = 0x00;

    ADC0_ACTSS_R &= 0xE;
    ADC0_EMUX_R &= 0xFFF0;
    ADC0_SSMUX0_R |= 0xA;
    ADC0_SSCTL0_R = 0x6;
    ADC0_ACTSS_R |= 0b0000001;
}

uint16_t adc_read(void) {
  ADC0_PSSI_R |= 0x01;
  ADC0_IM_R &= 0x1;
  while((ADC0_RIS_R & ADC0_IM_R) == 1) {

  }
  ADC0_ISC_R = 0x1;
  return ADC0_SSFIFO0_R;
}






/*
 * servo.h
 *
 *  Created on: Apr 9, 2025
 *      Author: pgeiken
 */

#ifndef SERVO_H_
#define SERVO_H_

void servo_init(void);

void servo_move(uint16_t degrees);



#endif /* SERVO_H_ */

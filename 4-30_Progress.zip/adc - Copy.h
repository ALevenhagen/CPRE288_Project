/*
 * adc.h
 *
 *  Created on: Apr 30, 2025
 *      Author: levenaub
 */

#ifndef ADC_H_
#define ADC_H_
#include <stdint.h>
#include <math.h>

void adc_init();
uint16_t adc_read();




#endif /* ADC_H_ */

///*
// * Scan.c
// *
// *  Created on: Apr 30, 2025
// *      Author: levenaub
// */
//#include "servo.h"
//#
//void Scan(int angle){
//
//}
//


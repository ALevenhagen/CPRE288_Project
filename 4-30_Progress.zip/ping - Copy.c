/**
 * Driver for ping sensor
 * @file ping.c
 * @author
 */

#include "ping.h"
#include "Timer.h"
#include "lcd.h"
#include <inc/tm4c123gh6pm.h>
#include <stdint.h>
#include <stdbool.h>

// Global shared variables
// Use extern declarations in the header file

volatile uint32_t g_start_time = 0;
volatile uint32_t g_end_time = 0;
volatile PingState g_state = LOW; // State of ping echo pulse
volatile int g_overflow_count = 0;
volatile uint32_t pulse_width = 0;

void ping_init (void){

  // YOUR CODE HERE
    SYSCTL_RCGCTIMER_R |= 0x08;             //Enable clock for timer 3
    SYSCTL_RCGCGPIO_R |= 0x02;              //Enable clock for Port B
    while((SYSCTL_PRGPIO_R & 0X02) == 0);   //Wait for GPIOB to be ready

    GPIO_PORTB_DEN_R |= 0x08;
    GPIO_PORTB_AFSEL_R |= 0x08;
    GPIO_PORTB_PCTL_R &= ~0x0000F000;
    GPIO_PORTB_PCTL_R |= 0x00007000;

    TIMER3_CTL_R &= ~TIMER_CTL_TBEN;
    TIMER3_CFG_R = 0x04;
    TIMER3_TBMR_R = 0x07;
    TIMER3_CTL_R |= TIMER_CTL_TBEVENT_BOTH;
    TIMER3_TBPR_R = 0xFF;
    TIMER3_TBILR_R = 0xFFFF;
    TIMER3_IMR_R |= TIMER_IMR_CBEIM;

    NVIC_EN1_R |= 1 << ((35 - 32) + 1);
    IntRegister(INT_TIMER3B, TIMER3B_Handler);

    IntMasterEnable();

    // Configure and enable the timer
    TIMER3_CTL_R |= TIMER_CTL_TBEN;
}

void ping_trigger (void){
    g_state = LOW;
    // Disable timer and disable timer interrupt
    TIMER3_CTL_R &= ~TIMER_CTL_TBEN;
    TIMER3_IMR_R &= ~TIMER_IMR_CBEIM;
    // Disable alternate function (disconnect timer from port pin)
    GPIO_PORTB_AFSEL_R &= ~0x08;

    // YOUR CODE HERE FOR PING TRIGGER/START PULSE
    GPIO_PORTB_DIR_R |= 0x08;
    GPIO_PORTB_DATA_R &= ~0x08;
    timer_waitMicros(5);
    GPIO_PORTB_DATA_R |= 0x08;
    timer_waitMicros(5);
    GPIO_PORTB_DATA_R &= ~0x08;

    GPIO_PORTB_DIR_R &= ~0x08;
    GPIO_PORTB_AFSEL_R |= 0x08;

    // Clear an interrupt that may have been erroneously triggered
    TIMER3_ICR_R = TIMER_ICR_CBECINT;
    // Re-enable alternate function, timer interrupt, and timer
    TIMER3_IMR_R |= TIMER_IMR_CBEIM;
    TIMER3_CTL_R |= TIMER_CTL_TBEN;
}

void TIMER3B_Handler(void){

  // YOUR CODE HERE
  // As needed, go back to review your interrupt handler code for the UART lab.
  // What are the first lines of code in the ISR? Regardless of the device, interrupt handling
  // includes checking the source of the interrupt and clearing the interrupt status bit.
  // Checking the source: test the MIS bit in the MIS register (is the ISR executing
  // because the input capture event happened and interrupts were enabled for that event?
  // Clearing the interrupt: set the ICR bit (so that same event doesn't trigger another interrupt)
  // The rest of the code in the ISR depends on actions needed when the event happens.
    if (TIMER3_MIS_R & TIMER_MIS_CBEMIS) {
        TIMER3_ICR_R = TIMER_ICR_CBECINT;
        uint32_t time = (TIMER3_TBPR_R << 16) | TIMER3_TBR_R;
        if (g_state == LOW) {
            g_start_time = time;
            g_state = HIGH;
        } else if (g_state == HIGH) {
            g_end_time = time;
            g_state = DONE;
        }
    }
}

float ping_getDistance (void){

    // YOUR CODE HERE
    ping_trigger();
    int timeout = 0;
    while (g_state != DONE) {
        timer_waitMicros(10);
    }
    if (g_state != DONE) {
        lcd_printf("NO ECHO");
        return 0;
    }

    if (g_start_time >= g_end_time) {
        pulse_width = g_start_time - g_end_time;
    } else {                                    // Overflow occurs
        pulse_width = (g_start_time + (0xFFFFFF - g_end_time) + 1);
        g_overflow_count++;
    }
    float distance = ((pulse_width * 0.0625) / 2.0) * 0.0343;
    return distance;

}
